import React, { useState, useEffect } from 'react';
import { 
  Briefcase, 
  User, 
  LogOut, 
  PlusCircle, 
  MapPin, 
  Building2, 
  Search, 
  CheckCircle2,
  LogIn,
  UserPlus
} from 'lucide-react';

// Types
type UserType = 'Candidato' | 'Empresa';

interface UserData {
  id: string;
  nome: string;
  email: string;
  senha: string;
  tipo: UserType;
}

interface Job {
  id: string;
  titulo: string;
  empresa: string;
  localizacao: string;
  categoria: string;
  descricao: string;
  publicadoPor: string; // User ID
  dataPublicacao: string;
}

interface Application {
  id: string;
  jobId: string;
  userId: string;
  dataCandidatura: string;
}

export default function App() {
  // State
  const [view, setView] = useState<'home' | 'login' | 'register' | 'postJob'>('home');
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);
  const [users, setUsers] = useState<UserData[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('Todas');

  // Form States
  const [regForm, setRegForm] = useState({ nome: '', email: '', senha: '', tipo: 'Candidato' as UserType });
  const [loginForm, setLoginForm] = useState({ email: '', senha: '' });
  const [jobForm, setJobForm] = useState({ titulo: '', empresa: '', localizacao: 'Maputo', categoria: 'TI', descricao: '' });
  const [alert, setAlert] = useState<{ message: string; type: 'success' | 'danger' } | null>(null);

  // Load data from LocalStorage
  useEffect(() => {
    const savedUsers = localStorage.getItem('pem_users');
    const savedJobs = localStorage.getItem('pem_jobs');
    const savedApps = localStorage.getItem('pem_applications');
    const savedUser = localStorage.getItem('pem_currentUser');

    if (savedUsers) setUsers(JSON.parse(savedUsers));
    if (savedJobs) setJobs(JSON.parse(savedJobs));
    if (savedApps) setApplications(JSON.parse(savedApps));
    if (savedUser) setCurrentUser(JSON.parse(savedUser));

    // Initial dummy data if empty
    if (!savedJobs) {
      const dummyJobs: Job[] = [
        {
          id: '1',
          titulo: 'Estágio em Desenvolvimento Web',
          empresa: 'MozTech',
          localizacao: 'Maputo',
          categoria: 'TI',
          descricao: 'Procuramos estudantes apaixonados por React e Node.js para integrar a nossa equipa de desenvolvimento.',
          publicadoPor: 'system',
          dataPublicacao: new Date().toISOString()
        },
        {
          id: '2',
          titulo: 'Assistente de Logística',
          empresa: 'Beira Logistics',
          localizacao: 'Beira',
          categoria: 'Administração',
          descricao: 'Vaga para estágio na área de gestão de stocks e coordenação de transporte na Beira.',
          publicadoPor: 'system',
          dataPublicacao: new Date().toISOString()
        },
        {
          id: '3',
          titulo: 'Técnico de Suporte Júnior',
          empresa: 'Nampula Solutions',
          localizacao: 'Nampula',
          categoria: 'TI',
          descricao: 'Oportunidade para aprender sobre infraestrutura de rede e suporte ao utilizador final.',
          publicadoPor: 'system',
          dataPublicacao: new Date().toISOString()
        }
      ];
      setJobs(dummyJobs);
      localStorage.setItem('pem_jobs', JSON.stringify(dummyJobs));
    }
  }, []);

  // Save data to LocalStorage
  useEffect(() => {
    localStorage.setItem('pem_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('pem_jobs', JSON.stringify(jobs));
  }, [jobs]);

  useEffect(() => {
    localStorage.setItem('pem_applications', JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('pem_currentUser', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('pem_currentUser');
    }
  }, [currentUser]);

  // Handlers
  const showAlert = (message: string, type: 'success' | 'danger') => {
    setAlert({ message, type });
    setTimeout(() => setAlert(null), 3000);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (users.find(u => u.email === regForm.email)) {
      showAlert('Este email já está registado.', 'danger');
      return;
    }
    const newUser: UserData = { ...regForm, id: Date.now().toString() };
    setUsers([...users, newUser]);
    showAlert('Conta criada com sucesso! Faça login.', 'success');
    setView('login');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.email === loginForm.email && u.senha === loginForm.senha);
    if (user) {
      setCurrentUser(user);
      showAlert(`Bem-vindo, ${user.nome}!`, 'success');
      setView('home');
    } else {
      showAlert('Email ou senha incorretos.', 'danger');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    showAlert('Sessão terminada.', 'success');
    setView('home');
  };

  const handlePostJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || currentUser.tipo !== 'Empresa') return;

    const newJob: Job = {
      ...jobForm,
      id: Date.now().toString(),
      publicadoPor: currentUser.id,
      dataPublicacao: new Date().toISOString()
    };
    setJobs([newJob, ...jobs]);
    showAlert('Vaga publicada com sucesso!', 'success');
    setView('home');
    setJobForm({ titulo: '', empresa: '', localizacao: 'Maputo', categoria: 'TI', descricao: '' });
  };

  const handleApply = (jobId: string) => {
    if (!currentUser) {
      showAlert('Precisa de estar logado para se candidatar.', 'danger');
      setView('login');
      return;
    }
    if (currentUser.tipo !== 'Candidato') {
      showAlert('Apenas candidatos podem candidatar-se a vagas.', 'danger');
      return;
    }
    if (applications.find(a => a.jobId === jobId && a.userId === currentUser.id)) {
      showAlert('Já se candidatou a esta vaga.', 'danger');
      return;
    }

    const newApp: Application = {
      id: Date.now().toString(),
      jobId,
      userId: currentUser.id,
      dataCandidatura: new Date().toISOString()
    };
    setApplications([...applications, newApp]);
    showAlert('Candidatura enviada com sucesso!', 'success');
  };

  // Filters
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.titulo.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          job.empresa.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'Todas' || job.categoria === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-vh-100 d-flex flex-column">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div className="container">
          <a className="navbar-brand d-flex align-items-center" href="#" onClick={() => setView('home')}>
            <Briefcase className="me-2" size={28} />
            <span>Portal de Estágios Moçambique</span>
          </a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto align-items-center">
              <li className="nav-item">
                <a className="nav-link" href="#" onClick={() => setView('home')}>Início</a>
              </li>
              {currentUser ? (
                <>
                  {currentUser.tipo === 'Empresa' && (
                    <li className="nav-item">
                      <button className="btn btn-outline-primary ms-lg-3 d-flex align-items-center" onClick={() => setView('postJob')}>
                        <PlusCircle size={18} className="me-1" /> Publicar Vaga
                      </button>
                    </li>
                  )}
                  <li className="nav-item dropdown ms-lg-3">
                    <a className="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                      <User size={18} className="me-1" /> {currentUser.nome}
                    </a>
                    <ul className="dropdown-menu dropdown-menu-end shadow border-0">
                      <li><span className="dropdown-item-text text-muted small">{currentUser.tipo}</span></li>
                      <li><hr className="dropdown-divider" /></li>
                      <li>
                        <button className="dropdown-item text-danger d-flex align-items-center" onClick={handleLogout}>
                          <LogOut size={16} className="me-2" /> Sair
                        </button>
                      </li>
                    </ul>
                  </li>
                </>
              ) : (
                <>
                  <li className="nav-item ms-lg-3">
                    <button className="btn btn-link nav-link d-flex align-items-center" onClick={() => setView('login')}>
                      <LogIn size={18} className="me-1" /> Login
                    </button>
                  </li>
                  <li className="nav-item">
                    <button className="btn btn-primary ms-lg-2 d-flex align-items-center" onClick={() => setView('register')}>
                      <UserPlus size={18} className="me-1" /> Registar
                    </button>
                  </li>
                </>
              )}
            </ul>
          </div>
        </div>
      </nav>

      {/* Alerts */}
      <div className="container mt-3">
        {alert && (
          <div className={`alert alert-${alert.type} alert-dismissible fade show shadow-sm`} role="alert">
            {alert.type === 'success' ? <CheckCircle2 size={18} className="me-2" /> : null}
            {alert.message}
            <button type="button" className="btn-close" onClick={() => setAlert(null)}></button>
          </div>
        )}
      </div>

      {/* Main Content */}
      <main className="flex-grow-1 py-4">
        <div className="container">
          
          {view === 'home' && (
            <>
              {/* Hero Section */}
              <div className="bg-dark text-white p-5 rounded-4 mb-5 shadow-lg position-relative overflow-hidden" style={{
                backgroundImage: 'linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(https://picsum.photos/seed/maputo/1200/400)',
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}>
                <div className="position-relative z-1">
                  <h1 className="display-4 fw-bold mb-3">O teu futuro começa aqui 🇲🇿</h1>
                  <p className="lead mb-4">A maior plataforma de estágios em Moçambique. Conectamos talentos às melhores empresas.</p>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <div className="input-group input-group-lg shadow-sm">
                        <span className="input-group-text bg-white border-0"><Search size={20} /></span>
                        <input 
                          type="text" 
                          className="form-control border-0" 
                          placeholder="Pesquisar vagas ou empresas..." 
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="col-md-3">
                      <select 
                        className="form-select form-select-lg border-0 shadow-sm"
                        value={categoryFilter}
                        onChange={(e) => setCategoryFilter(e.target.value)}
                      >
                        <option value="Todas">Todas Categorias</option>
                        <option value="TI">TI</option>
                        <option value="Administração">Administração</option>
                        <option value="Engenharia">Engenharia</option>
                        <option value="Saúde">Saúde</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Jobs List */}
              <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="h4 fw-bold mb-0">Vagas Recentes</h2>
                <span className="text-muted">{filteredJobs.length} vagas encontradas</span>
              </div>

              <div className="row g-4">
                {filteredJobs.length > 0 ? (
                  filteredJobs.map(job => (
                    <div key={job.id} className="col-md-6 col-lg-4">
                      <div className="card h-100">
                        <div className="card-body">
                          <div className="d-flex justify-content-between mb-2">
                            <span className="badge badge-category rounded-pill px-3">{job.categoria}</span>
                            <small className="text-muted">{new Date(job.dataPublicacao).toLocaleDateString('pt-MZ')}</small>
                          </div>
                          <h5 className="card-title fw-bold mb-1">{job.titulo}</h5>
                          <p className="text-primary fw-medium mb-3 d-flex align-items-center">
                            <Building2 size={16} className="me-1" /> {job.empresa}
                          </p>
                          <p className="card-text text-muted small mb-4">
                            {job.descricao.length > 120 ? job.descricao.substring(0, 120) + '...' : job.descricao}
                          </p>
                          <div className="d-flex align-items-center text-muted small mb-4">
                            <MapPin size={16} className="me-1" /> {job.localizacao}
                          </div>
                        </div>
                        <div className="card-footer bg-white border-0 pt-0 pb-3">
                          <button 
                            className={`btn w-100 ${applications.find(a => a.jobId === job.id && a.userId === currentUser?.id) ? 'btn-success disabled' : 'btn-primary'}`}
                            onClick={() => handleApply(job.id)}
                          >
                            {applications.find(a => a.jobId === job.id && a.userId === currentUser?.id) ? 'Candidatado' : 'Candidatar-se'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-12 text-center py-5">
                    <Briefcase size={48} className="text-muted mb-3 opacity-25" />
                    <p className="text-muted">Nenhuma vaga encontrada para os critérios selecionados.</p>
                  </div>
                )}
              </div>
            </>
          )}

          {view === 'login' && (
            <div className="row justify-content-center">
              <div className="col-md-5">
                <div className="card shadow-sm p-4">
                  <h2 className="text-center fw-bold mb-4">Login</h2>
                  <form onSubmit={handleLogin}>
                    <div className="mb-3">
                      <label className="form-label">Email</label>
                      <input 
                        type="email" 
                        className="form-control" 
                        required 
                        value={loginForm.email}
                        onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
                      />
                    </div>
                    <div className="mb-4">
                      <label className="form-label">Senha</label>
                      <input 
                        type="password" 
                        className="form-control" 
                        required 
                        value={loginForm.senha}
                        onChange={(e) => setLoginForm({...loginForm, senha: e.target.value})}
                      />
                    </div>
                    <button type="submit" className="btn btn-primary w-100 py-2 mb-3">Entrar</button>
                    <p className="text-center mb-0">
                      Não tem conta? <a href="#" onClick={() => setView('register')}>Registe-se</a>
                    </p>
                  </form>
                </div>
              </div>
            </div>
          )}

          {view === 'register' && (
            <div className="row justify-content-center">
              <div className="col-md-6">
                <div className="card shadow-sm p-4">
                  <h2 className="text-center fw-bold mb-4">Criar Conta</h2>
                  <form onSubmit={handleRegister}>
                    <div className="mb-3">
                      <label className="form-label">Nome Completo</label>
                      <input 
                        type="text" 
                        className="form-control" 
                        required 
                        value={regForm.nome}
                        onChange={(e) => setRegForm({...regForm, nome: e.target.value})}
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Email</label>
                      <input 
                        type="email" 
                        className="form-control" 
                        required 
                        value={regForm.email}
                        onChange={(e) => setRegForm({...regForm, email: e.target.value})}
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Senha</label>
                      <input 
                        type="password" 
                        className="form-control" 
                        required 
                        value={regForm.senha}
                        onChange={(e) => setRegForm({...regForm, senha: e.target.value})}
                      />
                    </div>
                    <div className="mb-4">
                      <label className="form-label">Tipo de Conta</label>
                      <select 
                        className="form-select" 
                        value={regForm.tipo}
                        onChange={(e) => setRegForm({...regForm, tipo: e.target.value as UserType})}
                      >
                        <option value="Candidato">Candidato (Estudante)</option>
                        <option value="Empresa">Empresa</option>
                      </select>
                    </div>
                    <button type="submit" className="btn btn-primary w-100 py-2 mb-3">Registar</button>
                    <p className="text-center mb-0">
                      Já tem conta? <a href="#" onClick={() => setView('login')}>Faça Login</a>
                    </p>
                  </form>
                </div>
              </div>
            </div>
          )}

          {view === 'postJob' && currentUser?.tipo === 'Empresa' && (
            <div className="row justify-content-center">
              <div className="col-md-8">
                <div className="card shadow-sm p-4">
                  <h2 className="fw-bold mb-4 d-flex align-items-center">
                    <PlusCircle className="me-2 text-primary" /> Publicar Nova Vaga
                  </h2>
                  <form onSubmit={handlePostJob}>
                    <div className="row g-3">
                      <div className="col-md-6">
                        <label className="form-label">Título da Vaga</label>
                        <input 
                          type="text" 
                          className="form-control" 
                          placeholder="Ex: Estagiário de Contabilidade"
                          required 
                          value={jobForm.titulo}
                          onChange={(e) => setJobForm({...jobForm, titulo: e.target.value})}
                        />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Nome da Empresa</label>
                        <input 
                          type="text" 
                          className="form-control" 
                          placeholder="Ex: MozTech"
                          required 
                          value={jobForm.empresa}
                          onChange={(e) => setJobForm({...jobForm, empresa: e.target.value})}
                        />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Localização</label>
                        <select 
                          className="form-select" 
                          value={jobForm.localizacao}
                          onChange={(e) => setJobForm({...jobForm, localizacao: e.target.value})}
                        >
                          <option value="Maputo">Maputo</option>
                          <option value="Matola">Matola</option>
                          <option value="Beira">Beira</option>
                          <option value="Nampula">Nampula</option>
                          <option value="Tete">Tete</option>
                          <option value="Quelimane">Quelimane</option>
                        </select>
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Categoria</label>
                        <select 
                          className="form-select" 
                          value={jobForm.categoria}
                          onChange={(e) => setJobForm({...jobForm, categoria: e.target.value})}
                        >
                          <option value="TI">TI</option>
                          <option value="Administração">Administração</option>
                          <option value="Engenharia">Engenharia</option>
                          <option value="Saúde">Saúde</option>
                          <option value="Educação">Educação</option>
                        </select>
                      </div>
                      <div className="col-12">
                        <label className="form-label">Descrição da Vaga</label>
                        <textarea 
                          className="form-control" 
                          rows={5} 
                          placeholder="Descreva as responsabilidades e requisitos..."
                          required 
                          value={jobForm.descricao}
                          onChange={(e) => setJobForm({...jobForm, descricao: e.target.value})}
                        ></textarea>
                      </div>
                    </div>
                    <div className="mt-4 d-flex gap-2">
                      <button type="submit" className="btn btn-primary px-4">Publicar Vaga</button>
                      <button type="button" className="btn btn-light px-4" onClick={() => setView('home')}>Cancelar</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}

        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-top py-4 mt-auto">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-6 text-center text-md-start">
              <p className="mb-0 text-muted">&copy; 2026 Portal de Estágios Moçambique. Todos os direitos reservados.</p>
            </div>
            <div className="col-md-6 text-center text-md-end mt-3 mt-md-0">
              <span className="text-muted me-3">Feito com ❤️ em Moçambique 🇲🇿</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
